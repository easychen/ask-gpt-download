// 点击插件图标，打开index.html
// chrome.action.onClicked.addListener(function(tab) { 
//     console.log("click", tab);
//     // 如果 URL 为 "https://weibo.com/u/xxx"，则打开 index.html?uid=xxx
//     if (/^https:\/\/weibo\.com\/u\/(\d+)/.test(tab.url)) {
//         const uid = RegExp.$1;
//         chrome.tabs.create({ url: `index.html?uid=${uid}` });
//         // action popup
//         // const url = `index.html?uid=${uid}`;
//         // setTimeout(() => {
//         //     chrome.action.setPopup({popup: url});
//         // }, 1000);
//         // console.log(tab);
//         // chrome.windows.create({
//         //     url: `index.html?uid=${uid}`,
//         //     type: 'popup',
//         //     width: 500,
//         //     height: 800,
//         //     // left: Math.floor(tab.left) + 50,
//         //     // top: Math.floor(tab.top) + 50
//         // });
        
//     }
// });

chrome.runtime.onInstalled.addListener(function() {
    console.log('onInstalled');
    chrome.tabs.onUpdated.addListener(function(tabId, changeInfo, tab) {
      console.log(changeInfo);
        // https://weibo.com/u/1088413295
        if (changeInfo.url) {
            if( changeInfo.url.includes("https://weibo.com/u/") )
            {
                // action 显示 badge
                console.log("set action", tabId);
                chrome.action.setBadgeText({text: 'ASK', tabId});
                // show page action
                // chrome.action.show(tabId);
            }else
            {
                console.log("remove action", tabId);
                chrome.action.setBadgeText({text: '', tabId});
                // hide page action
                // chrome.action.hide(tabId);
            }     
        }
    });
  });
  