// 注册一个事件监听器，当页面加载完成时执行
document.addEventListener('DOMContentLoaded', function() {
    console.log('content.js loaded');
    
    // 获取当前页面的 URL
    var url = window.location.href;
    // 如果 URL 包含 "https://weibo.com/u/"，则添加一个按钮
    if (url.indexOf('https://weibo.com/u/') !== -1) {
      // 创建一个按钮元素

      var button = document.createElement('button');
      // 设置按钮的文本
      button.innerText = '问我的GPT分身';
      // 添加按钮的样式
      button.style.backgroundColor = '#ff0000';
      button.style.color = '#ffffff';
      button.style.border = 'none';
      button.style.padding = '10px';
      button.style.borderRadius = '5px';
      // 添加按钮的点击事件处理程序
      button.addEventListener('click', function() {
        // 在这里添加你的代码，当按钮被点击时执行的操作
        alert('你点击了“问我的GPT分身”按钮！');
      });
      // 给button包裹一个div
        var div = document.createElement('div');
        div.appendChild(button);

      // 将按钮添加到页面中
      var container = document.querySelector('.wbpro-side-main');
      // 将按钮添加到container顶部
      container.insertBefore(div, container.firstChild);
      console.log(container);
    }
  });